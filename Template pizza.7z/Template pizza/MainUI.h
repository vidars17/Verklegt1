#ifndef MAINUI_H
#define MAINUI_H


class MainUI
{
    public:
        MainUI();
        void welcomeUI();
        void adminUI();
        void salesUI();
        void bakerUI();
        void deliveryUI();
        void makeOrderUI();
        void makePizzaUI();
        virtual ~MainUI();

    protected:

    private:
};

#endif // MAINUI_H
