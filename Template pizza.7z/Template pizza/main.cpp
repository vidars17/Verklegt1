#include <iostream>
#include <string>
#include <fstream>
#include "MainUI.h"


using namespace std;

int main()
{
    MainUI mainUI;
    mainUI.welcomeUI();

    return 0;
}
